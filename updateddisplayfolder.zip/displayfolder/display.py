from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
import sys

from inner import *

class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("BlackJack Image Example")

        # setting  the geometry of window
        self.setGeometry(0, 0, 1200, 900)

        self.loadBackground()
        self.cnt = 0
        self.card = set_card()
        self.playercards = twocard(self.card)
        self.dealercards = twocard(self.card)
        self.dealercards = show_card(self.dealercards)
        print(self.dealercards)
        for i in show_card(self.playercards):
            self.loadPlayerCard(i, self.cnt)
            self.cnt += 80

        self.loadDealerCard(self.dealercards[0])
        # show all the widgets
        self.show()


    def loadPlayerCard(self, cardsuit, cnt):
        self.label = QLabel(self)
        self.pixmap = QPixmap(f"./PNG-cards-1.3/{cardsuit}").scaledToWidth(150)
        self.label.setPixmap(self.pixmap)
        self.label.move(cnt,300)
        self.label.resize(self.pixmap.width(),self.pixmap.height())


    def loadBackground(self):
        self.label = QLabel(self)
        self.pixmap = QPixmap(f"./PNG-cards-1.3/background.png").scaledToHeight(220)
        self.label.setPixmap(self.pixmap)
        self.label.move(80,0)
        self.label.resize(self.pixmap.width(), self.pixmap.height())

    def loadDealerCard(self, cardsuit):
        self.label = QLabel(self)
        self.pixmap = QPixmap(f"./PNG-cards-1.3/{cardsuit}").scaledToWidth(150)
        self.label.setPixmap(self.pixmap)
        self.label.resize(self.pixmap.width(), self.pixmap.height())

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Window()
    sys.exit(app.exec_())