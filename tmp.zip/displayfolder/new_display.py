from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from inner import *
from tkinter import *
import sys

class Button(QToolButton):
    def __init__(self, text, callback):
        super().__init__()
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.setText(text)
        self.clicked.connect(callback)

    def sizeHint(self):
        size = super(Button, self).sizeHint()
        size.setHeight(size.height() + 50)
        size.setWidth(max(size.width(), size.height()))
        return size

class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.money = load()
        self.betting_cost = 0

        self.l1 = QLabel(self)
        self.pixmap = QPixmap(f"./PNG-cards-1.3/background.png").scaledToHeight(220)
        self.l1.setPixmap(self.pixmap)
        self.l1.move(0, 0)
        self.l1.resize(self.pixmap.width(), self.pixmap.height())

        self.l2 = QLabel(self)
        self.pixmap = QPixmap(f"./PNG-cards-1.3/background.png").scaledToHeight(220)
        self.l2.setPixmap(self.pixmap)
        self.l2.move(80, 0)
        self.l2.resize(self.pixmap.width(), self.pixmap.height())

        self.l3 = QLabel(self)
        self.pixmap = QPixmap(f"./PNG-cards-1.3/background.png").scaledToHeight(220)
        self.l3.setPixmap(self.pixmap)
        self.l3.move(0, 450)
        self.l3.resize(self.pixmap.width(), self.pixmap.height())

        self.display = QLabel()
        self.b_display = QLabel('bet: '+ str(self.betting_cost))
        self.m_display = QLabel('money: ' + str(self.money))

        dealBtn = Button("deal", self.button_clicked)
        stayBtn = Button("stay", self.button_clicked)
        appendBtn = Button("new card", self.button_clicked)
        pbetBtn = Button("+100", self.button_clicked)
        mbetBtn = Button("-100", self.button_clicked)

        vbox1= QVBoxLayout()
        vbox1.addWidget(pbetBtn)
        vbox1.addWidget(mbetBtn)

        vbox2 = QVBoxLayout()
        vbox2.addStretch(1)
        vbox2.addWidget(self.display)
        vbox2.addWidget(self.b_display)
        vbox2.addWidget(self.m_display)

        hbox = QHBoxLayout()
        hbox.addLayout(vbox1)
        hbox.addWidget(dealBtn)
        hbox.addWidget(stayBtn)
        hbox.addWidget(appendBtn)

        vbox = QVBoxLayout()
        vbox.addStretch(1)
        vbox.addLayout(vbox2)
        vbox.addLayout(hbox)
        self.setLayout(vbox)


        self.setGeometry(0, 0, 1200, 900)
        self.setWindowTitle('Black Jack')
        self.show()


    def loadPlayerCard(self, cardsuit, cnt):
        self.label = QLabel(self)
        self.pixmap = QPixmap(f"./PNG-cards-1.3/{cardsuit}").scaledToHeight(220)
        self.label.setPixmap(self.pixmap)
        self.label.move(cnt,450)
        self.label.resize(self.pixmap.width(),self.pixmap.height())

    def loadBackground(self):
        self.label = QLabel(self)
        self.pixmap = QPixmap(f"./PNG-cards-1.3/background.png").scaledToHeight(220)
        self.label.setPixmap(self.pixmap)
        self.label.move(80,0)
        self.label.resize(self.pixmap.width(), self.pixmap.height())

    def loadDealerCard(self, cardsuit, cnt):
        self.label = QLabel(self)
        self.pixmap = QPixmap(f"./PNG-cards-1.3/{cardsuit}").scaledToWidth(150)
        self.label.setPixmap(self.pixmap)
        self.label.move(cnt, 0)
        self.label.resize(self.pixmap.width(), self.pixmap.height())

    def button_clicked(self):
        button = self.sender()
        key = button.text()
        if key == '+100':
            self.betting_cost += 100
            self.b_display.setText('bet: '+ str(self.betting_cost))
            # self.m_display.setText('money: ' + str(self.money))
        elif key == '-100':
            self.betting_cost -= 100
            self.b_display.setText('bet: ' + str(self.betting_cost))
            # self.m_display.setText('money: ' + str(self.money))
        elif key == 'deal':
            if self.betting_cost < 0:
                self.display.setText("Bet on the positive value.")
                self.betting_cost = 0
                self.b_display.setText('bet: ' + str(self.betting_cost))
                return

            elif self.betting_cost>0:
                if self.betting_cost > 1000:
                    self.display.setText("betting min is 1000")
                    self.betting_cost = 0
                    self.b_display.setText('bet: ' + str(self.betting_cost))
                    return
                elif self.betting_cost > self.money:
                    self.display.setText("You don't have much money")
                    self.betting_cost = 0
                    self.b_display.setText('bet: ' + str(self.betting_cost))
                    return
                else:
                    # 동작 안함
                    self.display.setText("let's start!")
                    self.b_display.setText('bet: ' + str(self.betting_cost))
                    self.b_display.setText('money: ' + str(self.money))

            else:
                self.display.setText("Please click betting number")
                return


            # 매 게임마다 카드 리셋후, 카드 지급, 내부와 외부 분리
            self.card = set_card()
            self.player = twocard(self.card)
            print(self.player[0],self.player[1])
            # print(self.dealer[0])
            # print(self.dealer[1])
            self.dealer = twocard(self.card)
            print(self.dealer[0], self.dealer[1])

            roop = True
            while roop:
                self.pixmap = QPixmap(f"./PNG-cards-1.3/"+self.dealer[0]+"background.png").scaledToHeight(220)
                self.l1.setPixmap(self.pixmap)
                self.l1.move(0, 0)
                self.l1.resize(self.pixmap.width(), self.pixmap.height())

                self.pixmap = QPixmap(f"./PNG-cards-1.3/" + self.player[0] + "background.png").scaledToHeight(220)
                self.l1.setPixmap(self.pixmap)
                self.l1.move(0, 450)
                self.l1.resize(self.pixmap.width(), self.pixmap.height())

                self.pixmap = QPixmap(f"./PNG-cards-1.3/" + self.player[0] + "background.png").scaledToHeight(220)
                self.l1.setPixmap(self.pixmap)
                self.l1.move(80, 450)
                self.l1.resize(self.pixmap.width(), self.pixmap.height())



            # print Gui 에서 안보임
            print('player')
            print(show_card(self.player))
            print('dealer')
            print(show_card(self.dealer))
            self.display.setText('player:' + show_card(self.player))
            self.display1.setText('dealer:' + show_card(self.dealer[1:]) + 'H')

            print(self.player[0])
            print(self.player[1])
            self.loadPlayerCard(self.player[0],0)
            self.cnt += 80
            self.loadPlayerCard(self.player[1],self.cnt)
            print(self.dealer[0])
            print(self.dealer[1])
            # marks[data // 13] + card_english[data % 13] + " "
            # self.loadPlayerCard(self.player[0],0)
            # self.cnt += 80
            # self.loadPlayerCard(self.player[1],self.cnt)
            # self.loadDealerCard(self.dealer[0],0)


            # 블랙잭 체크 추가
            black = 0
            for i in self.player:
                if i % 13 == 0:
                    black += 1
                elif i % 13 >= 10:
                    black += 2
                else:
                    pass
            if black == 3:
                self.display.setText(get_fight_text(3) + str(show_card(self.player)))
                self.money = set_money(self.money, self.betting_cost, 3)
                self.player.clear()
                self.dealer.clear()
                self.betting_display.setReadOnly(False)
                self.m_display.setText('money: ' + str(self.money))
                self.betting_display.setText('')

        elif key == 'push':
            # 카드를 받지 않은 상태에서 push 버튼 클릭시 문구 추가, 내부와 외부 분리
            cardappend(self.player, self.card)
            self.display.setText('player:' + show_card(self.player))
            print(show_card(self.player))
            if count(self.player) > 21:
                player_result = count(self.player)
                dealer_result = count(self.dealer)
                fight_num = fight(player_result, dealer_result)
                self.display.setText(get_fight_text(fight_num))
                self.money = set_money(self.money, self.betting_cost, fight_num)
                self.player.clear()
                self.dealer.clear()
                self.betting_display.setReadOnly(False)
                self.money_display.setText('Money:' + str(self.money))
                self.betting_display.setText('')

        elif key == 'end':
            # 딜러 알고리즘 추가
            try:
                if self.betting_cost >= 1000:
                    dealer_algo(count(self.dealer), self.dealer, self.card)
                self.display1.setText('dealer:' + show_card(self.dealer))
                # 플레이어와 딜러 숫자합 비교, 내부와 외부 분리
                player_result = count(self.player)
                dealer_result = count(self.dealer)
                fight_num = fight(player_result, dealer_result)
                self.display.setText(get_fight_text(fight_num))
                self.money = set_money(self.money, self.betting_cost, fight_num)
                self.player.clear()
                self.dealer.clear()
                self.betting_display.setReadOnly(False)
                self.money_display.setText('Money:' + str(self.money))
                self.betting_display.setText('')
                self.betting_cost = 0
            except:
                self.display.setText('Need Start')

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Window()
    sys.exit(app.exec_())