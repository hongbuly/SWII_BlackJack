from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
import sys

from inner import *

class Button(QToolButton):
    def __init__(self, text, callback):
        super().__init__()
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.setText(text)
        self.clicked.connect(callback)

    def sizeHint(self):
        size = super(Button, self).sizeHint()
        size.setHeight(size.height() + 50)
        size.setWidth(max(size.width(), size.height()))
        return size

class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("BlackJack Game")
        self.setWindowIcon(QIcon(f"./PNG-cards-1.3/blackjack.png"))
        # setting  the geometry of window
        self.setGeometry(0, 0, 1200, 900)
        self.center()

        self.money = load()
        self.betting_cost = 0

        self.display = QLabel()
        self.b_display = QLabel('bet: ' + str(self.betting_cost))
        self.m_display = QLabel('money: ' + str(self.money))

        dealBtn = Button("deal", self.button_clicked)
        stayBtn = Button("stay", self.button_clicked)
        appendBtn = Button("new card", self.button_clicked)
        resetBtn = Button("reset", self.button_clicked)
        pbetBtn = Button("+100", self.button_clicked)
        mbetBtn = Button("-100", self.button_clicked)

        vbox1 = QVBoxLayout()
        vbox1.addWidget(pbetBtn)
        vbox1.addWidget(mbetBtn)

        vbox2 = QVBoxLayout()
        vbox2.addStretch(1)
        vbox2.addWidget(self.display)
        vbox2.addWidget(self.b_display)
        vbox2.addWidget(self.m_display)

        hbox = QHBoxLayout()
        hbox.addLayout(vbox1)
        hbox.addWidget(dealBtn)
        hbox.addWidget(stayBtn)
        hbox.addWidget(appendBtn)
        hbox.addWidget(resetBtn)

        vbox = QVBoxLayout()
        vbox.addStretch(1)
        vbox.addLayout(vbox2)
        vbox.addLayout(hbox)
        self.setLayout(vbox)

        # self.loadDealerCard('background')

        # self.cnt = 0
        # self.card = set_card()
        # self.playercards = twocard(self.card)
        # self.dealercards = twocard(self.card)
        # self.dealercards = show_card(self.dealercards)
        # self.loadDealerCard(self.dealercards[0])
        # self.loadBackground()
        #
        # print(self.dealercards)
        # for i in show_card(self.playercards):
        #     self.loadPlayerCard(i, self.cnt)
        #     self.cnt += 80

        self.cntLst = [0,150,300,450,600,750]
        self.pl1 = QLabel(self)
        self.pl2 = QLabel(self)
        self.pl3 = QLabel(self)
        self.pl4 = QLabel(self)
        self.pl5 = QLabel(self)
        self.pl6 = QLabel(self)
        self.pLabel = [self.pl1,self.pl2,self.pl3,self.pl4,self.pl5, self.pl6]

        self.dl1 = QLabel(self)
        self.dl2 = QLabel(self)
        self.dl3 = QLabel(self)
        self.dl4 = QLabel(self)
        self.dl5 = QLabel(self)
        self.dl6 = QLabel(self)
        self.dLabel = [self.dl1,self.dl2,self.dl3,self.dl4,self.dl5, self.dl6]

        for pl in self.pLabel:
            idx = self.pLabel.index(pl)
            if idx == 0 or idx == 1:
                self.loadPPlayerCard(pl, 'background', self.cntLst[idx])
            else:
                self.loadPPlayerCard(pl,'white', self.cntLst[idx])
            # print(self.pLabel.index(pl))

        for dl in self.dLabel:
            idx = self.dLabel.index(dl)
            if idx == 0 or idx == 1:
                self.loadDDealerCard(dl,'background', self.cntLst[idx])
            else:
                self.loadDDealerCard(dl, 'white', self.cntLst[idx])


        # show all the widgets
        self.show()


    def loadPPlayerCard(self, label, cardsuit, cnt):
        self.pixmap = QPixmap(f"./PNG-cards-1.3/{cardsuit}").scaledToWidth(150)
        label.setPixmap(self.pixmap)
        label.move(cnt,300)
        label.resize(self.pixmap.width(),self.pixmap.height())
        # print('pWidth: ' + str(self.pixmap.width()) + ', pHeight: ' + str(self.pixmap.height()))
        # pWidth: 150, pHeight: 214
        #    :
        # pWidth: 150, pHeight: 227

    def loadDDealerCard(self, label, cardsuit, cnt):
        self.pixmap = QPixmap(f"./PNG-cards-1.3/{cardsuit}").scaledToWidth(150)
        label.setPixmap(self.pixmap)
        label.move(cnt,0)
        label.resize(self.pixmap.width(),self.pixmap.height())
        # print('dWidth: ' + str(self.pixmap.width() + ', dHeight: ' + str(self.pixmap.height()))
        # dWidth: 150, dHeight: 214
        #    :
        # dWidth: 150, dHeight: 227


    # 프로그램 센터에 배치
    def center(self):
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    # 카드 배치, 베팅 초기화
    def clear(self):
        for pl in self.pLabel:
            idx = self.pLabel.index(pl)
            if idx < 2:
                self.loadPPlayerCard(pl, 'background', self.cntLst[idx])
            else:
                self.loadPPlayerCard(pl, 'white', self.cntLst[idx])

        for dl in self.dLabel:
            idx = self.dLabel.index(dl)
            if idx < 2:
                self.loadDDealerCard(dl, 'background', self.cntLst[idx])
            else:
                self.loadDDealerCard(dl, 'white', self.cntLst[idx])

        self.betting_cost = 0
        self.b_display.setText('bet: ' + str(self.betting_cost))



    def button_clicked(self):
        button = self.sender()
        key = button.text()
        if key == '+100':
            self.betting_cost += 100
            self.b_display.setText('bet: '+ str(self.betting_cost))
            # self.m_display.setText('money: ' + str(self.money))
        elif key == '-100':
            self.betting_cost -= 100
            self.b_display.setText('bet: ' + str(self.betting_cost))
            # self.m_display.setText('money: ' + str(self.money))
        elif key == 'deal':
            if self.betting_cost < 0:
                self.display.setText("Bet on the positive value.")
                self.betting_cost = 0
                self.b_display.setText('bet: ' + str(self.betting_cost))
                return

            elif self.betting_cost > 0:
                if self.betting_cost > 1000:
                    self.display.setText("betting min is 1000")
                    self.betting_cost = 0
                    self.b_display.setText('bet: ' + str(self.betting_cost))
                    return
                elif self.betting_cost > self.money:
                    self.display.setText("You don't have much money")
                    self.betting_cost = 0
                    self.b_display.setText('bet: ' + str(self.betting_cost))
                    return
                else:
                    self.display.setText("let's start!")

                    self.card = set_card()
                    self.intPlayercards = twocard(self.card)
                    # print(self.intPlayercards)
                    # [34, 5]
                    self.intDealercards = twocard(self.card)
                    self.dealercards = intToString_card(self.intDealercards)
                    self.playercards = intToString_card(self.intPlayercards)
                    # print(self.intToString_card)
                    # ['hearts9', 'spades6']
                    self.loadPPlayerCard(self.pl1, self.playercards[0], self.cntLst[self.pLabel.index(self.pl1)])
                    self.loadPPlayerCard(self.pl2, self.playercards[1], self.cntLst[self.pLabel.index(self.pl2)])
                    self.loadDDealerCard(self.dl1, self.dealercards[0], self.cntLst[self.dLabel.index(self.dl1)])
                    # self.loadDDealerCard(self.dl2, self.dealercards[1], self.cntLst[self.dLabel.index(self.dl2)])

                    # 시작하자마자 burst 불가능
                    # if burst(count(self.intPlayercards)):
                    #     print("lose")
                    #     QMessageBox.about(self, "BlackJack", "you lose !")
                    #     return
                    if count(self.intPlayercards) == 21:
                        QMessageBox.about(self, "BlackJack", "Congratulations !\nBlack Jack!")
                        self.money = set_money(self.money, self.betting_cost, 3)
                        self.m_display.setText('money: ' + str(self.money))
                    return
            else:
                self.display.setText("Please click betting number")
                return

        elif key == 'new card':
            cardappend(self.intPlayercards, self.card)
            # print(self.intPlayercards)
            # [34, 5, 7]
            self.playercards = intToString_card(self.intPlayercards)
            for pl in self.pLabel:
                idx = self.pLabel.index(pl)
                if idx < len(self.intPlayercards):
                    self.loadPPlayerCard(pl, self.playercards[idx], self.cntLst[idx])
            if burst(count(self.intPlayercards)):
                QMessageBox.about(self, "BlackJack", "Burst !")
                self.money = set_money(self.money, self.betting_cost, 0)
                self.m_display.setText('money: ' + str(self.money))
                return
            elif count(self.intPlayercards) == 21:
                QMessageBox.about(self, "BlackJack", "Congratulations !\nBlack Jack !")
                self.money = set_money(self.money, self.betting_cost, 3)
                self.m_display.setText('money: ' + str(self.money))
                return
            else:
                return

        elif key == 'stay':
            self.loadDDealerCard(self.dl2, self.dealercards[1], self.cntLst[self.dLabel.index(self.dl2)])
            # player의 burst 메소드 이용
            if burst(count(self.intDealercards)):
                QMessageBox.about(self, "BlackJack", "you win!")
                self.money = set_money(self.money, self.betting_cost, 1)
                self.m_display.setText('money: ' + str(self.money))
                return
            else:
                # 딜러 카드 합이 17이상이면 더이상 추가 카드를 받을 수 없음
                while count(self.intDealercards) < 17:
                    cardappend(self.intDealercards, self.card)
                    self.dealercards = intToString_card(self.intDealercards)
                    for dl in self.dLabel:
                        idx = self.dLabel.index(dl)
                        if idx < len(self.intDealercards):
                            self.loadDDealerCard(dl, self.dealercards[idx], self.cntLst[idx])
                if burst(count(self.intDealercards)):
                    QMessageBox.about(self, "BlackJack", "you win !")
                    self.money = set_money(self.money, self.betting_cost, 3)
                    self.m_display.setText('money: ' + str(self.money))
                    return
                elif count(self.intDealercards) == 21:
                    QMessageBox.about(self, "BlackJack", "you lose !")
                    self.money = set_money(self.money, self.betting_cost, 0)
                    self.m_display.setText('money: ' + str(self.money))
                    return
                else:
                    res = fight(count(self.intPlayercards),count(self.intDealercards))
                    if res == 2:
                        QMessageBox.about(self, "BlackJack", "Draw !")
                        self.money = set_money(self.money, self.betting_cost, 2)
                        self.m_display.setText('money: ' + str(self.money))
                        return
                    elif res == 1:
                        QMessageBox.about(self, "BlackJack", "you win !")
                        self.money = set_money(self.money, self.betting_cost, 3)
                        self.m_display.setText('money: ' + str(self.money))
                        return
                    else:
                        QMessageBox.about(self, "BlackJack", "you lose !")
                        self.money = set_money(self.money, self.betting_cost, 0)
                        self.m_display.setText('money: ' + str(self.money))
                        return

        # if key == 'reset':
        else:
            for pl in self.pLabel:
                idx = self.pLabel.index(pl)
                if idx < 2:
                    self.loadPPlayerCard(pl, 'background', self.cntLst[idx])
                else:
                    self.loadPPlayerCard(pl, 'white', self.cntLst[idx])

            for dl in self.dLabel:
                idx = self.dLabel.index(dl)
                if idx < 2:
                    self.loadDDealerCard(dl, 'background', self.cntLst[idx])
                else:
                    self.loadDDealerCard(dl, 'white', self.cntLst[idx])

            self.betting_cost = 0
            self.b_display.setText('bet: ' + str(self.betting_cost))



if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Window()
    sys.exit(app.exec_())